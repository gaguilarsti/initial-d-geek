This is an Alexa trivia skill, based on a template provided by Amazon.

You can find the original template [here](https://github.com/amzn/alexa-skills-kit-js/tree/deprecated/samples/spaceGeek). 